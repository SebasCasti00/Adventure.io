package com.example.adventureio;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.Observable;
import java.util.Observer;

public class MainActivity extends AppCompatActivity implements Observer {

    Button continuar;
    private Comunicacion com;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        com = Comunicacion.instance();
        com.addObserver(this);
        Thread n = new Thread(com);
        n.start();
        continuar = findViewById(R.id.btn_comenzar);

        continuar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), Game.class);
                startActivity(i);
                com.enviar("Jugar");
            }
        });
    }

    @Override
    public void update(Observable observable, Object arg) {
        String message = (String) arg;
    }
}
