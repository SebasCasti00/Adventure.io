package com.example.adventureio;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.Observable;
import java.util.Observer;

public class Game extends AppCompatActivity implements Observer {

    Button up;
    Button down;
    Button left;
    Button right;

    private Comunicacion com;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        com = Comunicacion.instance();
        com.addObserver(this);

        up = findViewById(R.id.btn_arriba);
        up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                com.enviar("arriba");
            }
        });

        down = findViewById(R.id.btn_abajo);
        down.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                com.enviar("abajo");
            }
        });

        left = findViewById(R.id.btn_izquierda);
        left.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                com.enviar("izquierda");
            }
        });

        right = findViewById(R.id.btn_derecha);
        right.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                com.enviar("derecha");
            }
        });
    }

    @Override
    public void update(Observable observable, Object o) {

    }
}
