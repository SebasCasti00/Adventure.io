package com.example.adventureio;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Observable;

public class Comunicacion extends Observable implements Runnable {

    private static Comunicacion ref;
    private Socket s;
    private DataInputStream entrada;
    private DataOutputStream salida;
    private InetAddress address;
    private boolean conectado;

    private Comunicacion() {
        conectado = false;
    }

    public static Comunicacion instance() {
        if (ref == null) {
            ref = new Comunicacion();
        }
        return ref;
    }

    @Override
    public void run() {
        if (!conectado) {
            try {
                address = InetAddress.getByName("192.168.0.2");
                s = new Socket(address, 5000);
                salida = new DataOutputStream(s.getOutputStream());
                entrada = new DataInputStream(s.getInputStream());
                conectado = true;
                salida.writeUTF("bruh");
            } catch (UnknownHostException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        while(true){
            try {
                recibir();
                Thread.sleep(20);
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void recibir() throws IOException{
        if(conectado){
            String messageReceived = entrada.readUTF();
            setChanged();
            notifyObservers(messageReceived);
            clearChanged();
        }
    }

    public void enviar(final String message){
        if (conectado) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        salida.writeUTF(message);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }).start();
        }
    }
}
