package Adventure;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Observable;

public class Clients extends Observable implements Runnable{

	private Socket s;
	private DataOutputStream salida;
	private DataInputStream entrada;
	
	
	public Clients(Socket socketnew) {
		this.s = socketnew;
		try {
			salida = new DataOutputStream(s.getOutputStream());
			entrada = new DataInputStream(s.getInputStream());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		while(true) {
			try {
				recibir();
				Thread.sleep(10);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public void enviar(String message) {
		if(s != null && s.isConnected() && !s.isClosed()) {
			new Thread(new Runnable() {
				public void run() {
					try {
						salida.writeUTF(message);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}).start();
		}
	}

	private void recibir() {
		if (s != null && s.isConnected() && !s.isClosed()) {
			try {
				String mnsj = entrada.readUTF();
				setChanged();
				notifyObservers(mnsj);
				clearChanged();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
