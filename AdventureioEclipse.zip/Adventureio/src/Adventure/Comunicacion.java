package Adventure;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Observable;
import java.util.Observer;

public class Comunicacion extends Observable implements Runnable, Observer {

	private static Comunicacion com;
	private ServerSocket ss;
	private ArrayList<Clients> clients;

	private Comunicacion() {
		try {
			ss = new ServerSocket(5000);
			clients = new ArrayList<>();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static Comunicacion getSingleton() {
		if (com == null) {
			com = new Comunicacion();
		}
		return com;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		while (true) {
			if (clients.size() < 2) {
				try {
					recibirClientes();
					Thread.sleep(20);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

	@Override
	public void update(Observable o, Object arg) {
		// TODO Auto-generated method stub
		setChanged();
		notifyObservers((String) arg);
		clearChanged();
	}

	private void recibirClientes() throws IOException {

		Socket newsocket = ss.accept();
		Clients newclient = new Clients(newsocket);
		clients.add(newclient);

		Thread n = new Thread(newclient);
		n.start();
		if(clients.size()== 1) {
			clients.get(0).enviar("player1");
		}else if(clients.size()== 2) {
			clients.get(1).enviar("player2");
		}
		newclient.addObserver(this);
		System.out.println(clients.size());
	}
}
