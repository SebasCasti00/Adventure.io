package Adventure;

import processing.core.PApplet;
import processing.core.PImage;

public class Usuario {

	int x1;
	int y1;
	int vel;
	int tam;
	int usuario;
	
	String mover;
	
	boolean player1;
	boolean velB;
	boolean key;
	int puntaje;
	PImage plyr, fondo;
	PApplet app;
	
	Clients client;


	public Usuario(PApplet appExt, int posX1, int posY1, PImage player, boolean key) {

		app = appExt;
		player1 = true;
		velB = true;
		key = false;
		vel = 10;
		tam = 15;
		
		x1 = posX1;
		y1 = posY1;
		plyr = player;
		
		fondo = app.loadImage("Adventure/fondo.png");
	}

	public void pintarUsuario() {
		
		fondo.loadPixels();
		app.rectMode(app.CENTER);
		app.image(plyr, x1, y1, tam, tam);
		
	}

	public void moverUsuario() {
		
			
	}
	
	public void setUsuario(int x) {
		this.usuario = x;
	}

	public void Setmover(String mover) {
		// TODO Auto-generated method stub
		this.mover = mover;
		System.out.println("mover es"+mover);
	}
}

/*
 * public int getX() { return x; }
 * 
 * public int getY() { return y; }
 * 
 * public void setX(int UsX){ this.x = UsX; }
 * 
 * public void setY(int UsY) { this.y = UsY; }
 */
