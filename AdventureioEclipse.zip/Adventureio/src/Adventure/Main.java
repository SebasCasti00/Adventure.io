package Adventure;

import java.util.Observable;
import java.util.Observer;

import processing.core.PApplet;
import processing.core.PImage;

public class Main extends PApplet implements Observer{
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PApplet.main("Adventure.Main");
	}
	
	
	Usuario usuario1;
	Usuario usuario2;
	int pantalla;
	PImage fondo, key, continuar, listo, fondointro, player1txt, player2txt, player1, player2;
	boolean instrucciones;
	boolean listo1;
	boolean listo2;

	public void settings() {
		size(1200,700);
	}
	
	public void setup() {
		pantalla = 0;
		
		fondo = loadImage("Adventure/fondo.png");
		fondointro = loadImage("Adventure/fondointro.png");
		continuar = loadImage("Adventure/jugar.png");
		listo = loadImage("Adventure/listo.png");
		player1txt = loadImage("Adventure/player1.png");
		//player2txt = loadImage("Adventure/player2.png");
		player1 = loadImage("Adventure/p1.png");
		//player2 = loadImage("Adventure/p2.png");
		usuario1 = new Usuario(this, 40, 10, player1, false);
		//usuario2 = new Usuario(this, 1140, 10, player2, false);
		key = loadImage("Adventure/key.png");
		listo1 = true;
		//listo2 = true;
		
	}
	
	public void draw() {
		
		switch(pantalla) {
		case 0:
			image(fondointro, 0,0, 1200, 700);
			image(player1txt, 370, 300, 100, 20);
			//image(player2txt, 730, 310, 100, 20);
			image(player1, 400, 350, 50, 50);
			//image(player2, 750, 350, 50,50);
			
			if(listo1 == true) {
				image(listo, 375, 415, 80, 18);
			}
			
			if(listo2 == true) {
				image(listo, 735, 415, 80, 18);
			}
			
			break;
			
		case 1:
			image(fondo, 0, -2,1200,704);
			usuario1.pintarUsuario();
			//usuario2.pintarUsuario();
			usuario1.moverUsuario();
			//usuario2.moverUsuario();
			image(key, 590, 340, 20,20);
		}
		
	}


	@Override
	public void update(Observable arg0, Object arg1) {
		// TODO Auto-generated method stub
		String message = (String) arg1;
		if(message.contains("arriba")) {
			usuario1.Setmover("arriba");
		}
	}
	
	public void mouseClicked() {
		pantalla += 1;
	}
}
